import React, { useState } from 'react';
import { Text, View, ScrollView, Image, TouchableOpacity, Platform, UIManager, LayoutAnimation } from 'react-native';
import styles from './Style';

const NotificationItem = ({ notification }) => {
    const [showFullText, setShowFullText] = useState(false);
    const [showGroupedMessages, setShowGroupedMessages] = useState(false);
    const [expanded, setExpanded] = useState(false);

    Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental && UIManager.setLayoutAnimationEnabledExperimental(true);

    let appName = notification.app.split('.').pop();
    if (notification.app.toLowerCase().includes('messaging')) {
        appName = 'Message';
    } else if (notification.app.toLowerCase().includes('notification')) {
        appName = 'App Notification';
    } else if (notification.app.toLowerCase() === 'com.google.android.youtube') {
        appName = 'Youtube';
    } else if (notification.app.toLowerCase() === 'com.whatsapp.w4b') {
        appName = 'Whatsapp Business';
    } else if (notification.app.toLowerCase() === 'com.instagram.android') {
        appName = 'Instagram';
    } else if (notification.app.toLowerCase() === 'com.ak.ta.dainikbhaskar.activity') {
        appName = 'Dainik Bhaskar';
    } else if (notification.app.toLowerCase().startsWith('com.')) {
        const packageName = notification.app.split('.');
        if (packageName.length > 2) {
            const middleName = packageName[1].charAt(0).toUpperCase() + packageName[1].slice(1);
            appName = middleName;
        } else {
            appName = packageName[1].charAt(0).toUpperCase() + packageName[1].slice(1);
        }
    }

    const toggleFullText = () => {
        setShowFullText(!showFullText);
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setExpanded(!expanded);
    };

    const toggleGroupedMessages = () => {
        setShowGroupedMessages(!showGroupedMessages);
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setExpanded(!expanded);
    };

    const options = { hour: 'numeric', minute: 'numeric' };
    const formatDate = (date) => {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear().toString().slice(-2);
        return `${day}/${month}/${year}`;
    };


    console.log('Fetching Data........', notification.app.toLowerCase());

    return (
        <TouchableOpacity style={styles.notificationWrapper} disabled={true}>
            <View style={styles.notificationContainer}>
                <View style={styles.iconContainer}>
                    {false ? (
                        <Image
                            style={styles.icon}
                            source={{ uri: notification.icon }}
                        />
                    ) : (
                        notification.app.toLowerCase().includes('whatsapp') ? (
                            notification.app.toLowerCase() === 'com.whatsapp.w4b' ? (
                                <Image
                                    style={styles.Emptyicon}
                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/whatsappBusiness.png')}
                                />
                            ) : (
                                <Image
                                    style={styles.Emptyicon}
                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/whatsapp.png')}
                                />
                            )
                        ) : (
                            notification.app.toLowerCase().includes('telegram') ? (
                                <Image
                                    style={styles.Emptyicon}
                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/telegram.png')}
                                />
                            ) : (
                                notification.app.toLowerCase().includes('skype') ? (
                                    <Image
                                        style={styles.Emptyicon}
                                        source={require('/Users/ntf-m4/Desktop/notification/src/Assets/skype.png')}
                                    />
                                ) : (
                                    notification.app.toLowerCase().includes('messaging') ? (
                                        <Image
                                            style={styles.Emptyicon}
                                            source={require('/Users/ntf-m4/Desktop/notification/src/Assets/chat.png')}
                                        />
                                    ) : (
                                        notification.app.toLowerCase().includes('snapchat') ? (
                                            <Image
                                                style={styles.Emptyicon}
                                                source={require('/Users/ntf-m4/Desktop/notification/src/Assets/snapchat.png')}
                                            />
                                        ) : (
                                            notification.app.toLowerCase().includes('instagram') ? (
                                                <Image
                                                    style={styles.Emptyicon}
                                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/instagram.png')}
                                                />
                                            ) : (
                                                notification.app.toLowerCase().includes('linkedin') ? (
                                                    <Image
                                                        style={styles.Emptyicon}
                                                        source={require('/Users/ntf-m4/Desktop/notification/src/Assets/linkedin.png')}
                                                    />
                                                ) : (
                                                    notification.app.toLowerCase().includes('gmail') ? (
                                                        <Image
                                                            style={styles.Emptyicon}
                                                            source={require('/Users/ntf-m4/Desktop/notification/src/Assets/gmail.png')}
                                                        />
                                                    ) : (
                                                        notification.app.toLowerCase().includes('flipkart') ? (
                                                            <Image
                                                                style={styles.Emptyicon}
                                                                source={require('/Users/ntf-m4/Desktop/notification/src/Assets/flipkart.png')}
                                                            />
                                                        ) : (
                                                            notification.app.toLowerCase().includes('amazon') ? (
                                                                <Image
                                                                    style={styles.Emptyicon}
                                                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/amazon.png')}
                                                                />
                                                            ) : (
                                                                notification.app.toLowerCase().includes('paytm') ? (
                                                                    <Image
                                                                        style={styles.Emptyicon}
                                                                        source={require('/Users/ntf-m4/Desktop/notification/src/Assets/paytm.png')}
                                                                    />
                                                                ) : (
                                                                    notification.app.toLowerCase().includes('phonepay') ? (
                                                                        <Image
                                                                            style={styles.Emptyicon}
                                                                            source={require('/Users/ntf-m4/Desktop/notification/src/Assets/phonepay.png')}
                                                                        />
                                                                    ) : (
                                                                        notification.app.toLowerCase().includes('youtube') ? (
                                                                            <Image
                                                                                style={styles.Emptyicon}
                                                                                source={require('/Users/ntf-m4/Desktop/notification/src/Assets/youtube.png')}
                                                                            />
                                                                        ) : (
                                                                            notification.app.toLowerCase() === 'com.ak.ta.dainikbhaskar.activity' ? (
                                                                                <Image
                                                                                    style={styles.Emptyicon}
                                                                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/world-news.png')}
                                                                                />
                                                                            ) : (
                                                                                <Image
                                                                                    style={styles.Emptyicon}
                                                                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/download.png')}
                                                                                />
                                                                            )
                                                                        )
                                                                    )
                                                                )
                                                            )
                                                        )
                                                    )
                                                )
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )}
                </View>


                <View style={styles.notificationContent}>
                    <Text style={styles.appName}>{appName}</Text>
                    <TouchableOpacity onPress={toggleFullText}>
                        <Text style={styles.sender}>
                            {showFullText ? notification.title : notification.title.length > 60 ? notification.title.slice(0, 60) : notification.title}
                            {!showFullText && notification.title.length > 60 && <Text style={styles.ellipsis}>...</Text>}
                        </Text>
                        {/* {console.log('GROUP MESSAGE>>', notification.groupedMessages)} */}
                        <Text style={styles.message}>
                            {showGroupedMessages && notification.groupedMessages && notification.groupedMessages.length > 0 ?
                                notification.groupedMessages.slice().reverse().map((msg, index) => (
                                    <Text key={index}>{msg.text}{'\n'}</Text>
                                )) :
                                (showFullText ? notification.text : notification.text.length > 80 ? notification.text.slice(0, 80) : notification.text)
                            }

                            {!showFullText && notification.text.length > 80 && <Text style={styles.ellipsis}>...</Text>}
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.timeAndDateContainer}>
                    <View style={styles.timeContainer}>
                        <Text style={styles.time}>
                            {new Date(parseInt(notification.time)).toLocaleTimeString([], options)}
                        </Text>
                    </View>
                    <View style={styles.dateContainer}>
                        <Text style={styles.date}>
                            {formatDate(new Date(parseInt(notification.time)))}
                        </Text>
                    </View>

                    {notification.groupedMessages && notification.groupedMessages.length > 0 &&
                        <TouchableOpacity onPress={toggleGroupedMessages}>
                            <Text style={{ fontSize: 12, marginTop: 25, color: '#0390fc' }}>{showGroupedMessages ? 'Hide' : 'See more'}</Text>
                        </TouchableOpacity>
                    }
                </View>
            </View>
        </TouchableOpacity>
    );
};
const NotificationList = ({ notifications }) => {
    return (
        <View style={styles.scroll}>
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {notifications && notifications.length > 0 ? (
                    notifications.slice().reverse().map((notification, index) => (
                        <NotificationItem key={index} notification={notification} />
                    ))
                ) : (
                    <Text style={styles.noRecent}>No Recent Notifications</Text>
                )}
            </ScrollView>
        </View>
    );
};


export default NotificationList;
