import { Dimensions, StyleSheet } from 'react-native';

const { width } = Dimensions.get('screen');

export default styles = {
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 10,
        // marginTop: 20,
    },
    button: {
        backgroundColor: '#55a1f2',
        paddingVertical: 8,
        paddingHorizontal: 40,
        borderRadius: 5,
        marginHorizontal: 5, // Adjust horizontal margin as needed
    },
    delBtn: {
        justifyContent: 'center',
        backgroundColor: '#FF4155',
        // paddingVertical: 10,
        paddingHorizontal: width * 0.03,
        borderRadius: 5,
    },
    noRecent: {
        fontSize: 22,
        marginHorizontal: 1,
        textAlign: 'center', // Center text horizontally
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        textAlign: 'center',
        width: width * 0.6
    },
    scroll: {
        flex: 1,
        backgroundColor: '#fff',
    },
    scrollContent: {
        flexGrow: 1,
        paddingBottom: 20,
    },
    notificationWrapper: {
        backgroundColor: '#fff',
        borderRadius: 10,
        marginHorizontal: 20,
        marginVertical: 5,
        padding: 15,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    notificationContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    iconContainer: {
        width: 50, // Adjust width as needed
        height: 50, // Adjust height as needed
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 10, // Adjust margin as needed
    },
    icon: {
        width: '100%',
        height: '100%',
        resizeMode: 'contain', // Adjust resizeMode as needed
    },
    refresh: {
        height: 20,
        width: 20,
        resizeMode: 'contain'
    },
    Emptyicon: {
        width: '80%',
        height: '80%',
        resizeMode: 'contain',
    },
    notificationContent: {
        flex: 1,
    },
    appName: {
        fontSize: 13,
        fontWeight: 'bold',
        marginBottom: 5,
        color: '#333',
    },
    sender: {
        fontWeight: '500',
        marginBottom: 2,
        color: '#555',
    },
    message: {
        fontSize: 13,
        marginBottom: 2,
        color: '#777',
    },
    timeAndDateContainer: {
        // marginTop: 10, // Adjust this value as needed
    },
    timeContainer: {

    },
    dateContainer: {
    },
    time: {
        fontSize: 10,
        color: '#999',
    },
    date: {
        fontSize: 10,
        color: '#888',
    },
    ellipsis: {
        color: '#1e80e8',
        fontSize: 16,
        fontWeight: 'bold'
    }, notificationListContainer: {
        flex: 1,
        marginTop: 10,
    },
    copyButton: {
        height: 20,
        width: 20,
        marginLeft: 22,
        // marginTop: 40,
        resizeMode: 'contain', // Adjust resizeMode as needed

    },
        loadingContainer: {
            justifyContent: 'center',
            alignItems: 'center',
        }
    
};
