import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, ActivityIndicator, Dimensions, Alert } from 'react-native';
import storage from '@react-native-firebase/storage';
import { useRoute } from '@react-navigation/native';
import NotificationList from './NotificationList';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ShowData = () => {
    const [notifications, setNotifications] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const [loading, setLoading] = useState(true);
    const route = useRoute();
    const navigation = useNavigation();
    const isFocused = useIsFocused();

    useEffect(() => {
        if (isFocused) {
            fetchData();
            console.log("Fetching Data In Firebase...");
        }
    }, [isFocused]);
    const fetchData = async () => {
        try {
            const { filename } = route.params;
            const reference = storage().ref(`uploads/notifications_${filename}.json`);
            const url = await reference.getDownloadURL();
            const response = await fetch(url);
            const data = await response.json();
            await AsyncStorage.setItem('Childs_ID', filename)
            setNotifications(data);
            setRefreshing(false);
            setLoading(false);
        } catch (error) {
            if (error.code === 'storage/object-not-found') {
                Alert.alert('Incorrect Key', 'please re-enter key');
                navigation.navigate('ParentScreen')
            } else {
                Alert.alert('Error downloading data from Firebase Storage:', error);
            }
            setRefreshing(false);
            setLoading(false);
        }
    };

    const handleRefresh = () => {
        console.log("Fetching Data In Firebase...2");
        setRefreshing(true);
        fetchData();
    };

    const handleDisconnect = async () => {
        navigation.navigate('ParentChild');
        await AsyncStorage.setItem('Childs_ID', '');
    }

    return (
        <View style={styles.container}>
            {loading ? null : <TouchableOpacity style={styles.delBtn} onPress={handleDisconnect}>
                <Text style={{ color: 'white', fontWeight: 'bold' }}>Disconnect</Text>
            </TouchableOpacity>}
            <ScrollView
                style={styles.scrollView}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={handleRefresh}
                        colors={['#FF4155']}
                    />
                }
            >
                {loading ? (
                    <View style={[styles.loadingContainer, { height: screenHeight * 0.75 }]}>
                        <ActivityIndicator size="large" color="#FF4155" />
                    </View>
                ) : (
                    notifications.length === 0 ? (
                        <Text style={styles.noRecent}>No Recent Notifications</Text>
                    ) : (
                        <NotificationList notifications={notifications} />
                    )
                )}



            </ScrollView>
        </View>
    );

};
const window = Dimensions.get('window');
const screenHeight = window.height;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        // marginTop:15
    },
    scrollView: {
        flex: 1,
    },
    delBtn: {
        position: 'absolute',
        bottom: 30,
        left: 20,
        alignItems: 'center',
        backgroundColor: 'rgba(255, 65, 85, 0.9)',
        color: 'white',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 10,
        zIndex: 1,
    },
    noRecent: {
        fontSize: 22,
        marginHorizontal: 1,
        textAlign: 'center',
    },
    button: {
        backgroundColor: '#55a1f2',
        paddingVertical: 8,
        borderRadius: 5,
        marginHorizontal: 5,
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        textAlign: 'right',
    },
    loadingContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    }
});

export default ShowData;
