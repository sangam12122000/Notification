import React, { useState, useEffect, useCallback } from 'react';
import {
    SafeAreaView,
    ScrollView,
    Text,
    View,
    Image,
    TouchableOpacity,
    ActivityIndicator,
    RefreshControl,
    Dimensions
} from 'react-native';
import RNAndroidNotificationListener from 'react-native-android-notification-listener';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './Style';
import NotificationList from './NotificationList';
import { useNavigation } from '@react-navigation/native';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import auth from '@react-native-firebase/auth';

function Store() {
    const [hasPermission, setHasPermission] = useState(false);
    const [lastNotifications, setLastNotifications] = useState([]);
    const [delLoading, setDelLoading] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [loadingData, setLoadingData] = useState(true); // New state for loading indicator
    const navigation = useNavigation();

    const handleOnPressPermissionButton = async () => {
        RNAndroidNotificationListener.requestPermission();
    };

    const handleAppStateChange = async (nextAppState, force = false) => {
        if (nextAppState === 'active' || force) {
            const status = await RNAndroidNotificationListener.getPermissionStatus();
            setHasPermission(status !== 'denied');
        }
    };
    useEffect(() => {
        let interval = null;
        clearInterval(interval);
        interval = setInterval(handleNotificationShow, 2000);
        // uploadToFirebaseStorage(); // Call the function to upload data
        handleAppStateChange('', true);
    }, []);

    const handleNotificationShow = useCallback(async () => {
        try {
            const allNotifications = await AsyncStorage.getItem('notifications');
            if (allNotifications) {
                const notifications = JSON.parse(allNotifications);
                setLastNotifications(notifications);
            } else {
                // console.log('No notifications found.');
            }
        } catch (error) {
            console.error('Error retrieving notifications:', error);
        } finally {
            setLoadingData(false); // Set loading state to false once data fetching is done
        }
    }, []);

    const handleRefresh = useCallback(() => {
        setRefreshing(true);
        handleNotificationShow();
        setTimeout(() => {
            setRefreshing(false);
        }, 2000);
    }, [handleNotificationShow]);


    const loading = () => {
        setDelLoading(true);
        setTimeout(() => {
            handleGoogleLogout();
            setDelLoading(false);
        }, 2000);
    };

    const handleGoogleLogout = async () => {
        try {
            await auth().signOut();
            await GoogleSignin.signOut();
            console.log('Successfully signed out from Google');
            navigation.navigate('GoogleLogin');
        } catch (error) {
            console.error('Google Logout error:', error);
        }
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.buttonContainer}>
                <TouchableOpacity
                    disabled={hasPermission}
                    style={[styles.button, { backgroundColor: hasPermission ? '#b8c3cf' : '#007bff' }]}
                    onPress={handleOnPressPermissionButton}>
                    <Text style={styles.buttonText}>Permission for Android</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.delBtn} onPress={loading} disabled={delLoading}>
                    {delLoading ? (
                        <ActivityIndicator size={17} color="#ffffff" />
                    ) : (
                        <Image
                            source={require('/Users/ntf-m4/Desktop/notification/src/Assets/forward.png')}
                            style={{
                                height: 18,
                                width: 18,
                                resizeMode: 'contain',
                                tintColor: '#fff',

                            }}
                        />
                    )}
                </TouchableOpacity>
            </View>
            {loadingData ? ( // Conditionally render the activity indicator
                <View style={[styles.loadingContainer, { height: screenHeight * 0.73 }]}>
                    <ActivityIndicator size="large" color="#FF4155" />
                </View>
            ) : (
                <ScrollView
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={handleRefresh}
                            colors={['#FF4155']}
                        />
                    }>
                    {lastNotifications.length === 0 ? (
                        <Text style={styles.noRecent}>No Recent Notifications</Text>
                    ) : (
                        <NotificationList notifications={lastNotifications} />
                    )}
                </ScrollView>
            )}
        </SafeAreaView>
    );
}
const window = Dimensions.get('window');
const screenHeight = window.height;
export default Store;
