import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import auth from '@react-native-firebase/auth';

const UseCases = () => {
    const navigation = useNavigation();
    const [lastSignInTime, setLastSignInTime] = useState(null);
    useEffect(() => {
        checkGoogleSignIn();
    }, []);

    const checkGoogleSignIn = async () => {
        const unsubscribe = auth().onAuthStateChanged(user => {
            if (user) {
                // Convert timestamp to Date object
                const date = new Date(user.metadata.lastSignInTime);
                // Format the date and time
                const formattedDate = formatDate(date);
                // Set lastSignInTime from user metadata
                setLastSignInTime(formattedDate);
            } else {
                console.log('User is not signed in');
            }
        });

        return unsubscribe;
    };

    const formatDate = (date) => {
        const timeOptions = {
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        };
        const formattedTime = date.toLocaleString('en-US', timeOptions);

        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        const formattedDate = `${day}/${month}/${year}`;

        return `${formattedTime} ${formattedDate}`;
    };


    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.top}>
                <Text style={styles.title}>What's Your Use case?</Text>
            </View>
            <View style={styles.middle}>
                <Image source={require('/Users/ntf-m4/Desktop/notification/src/Assets/family.png')} style={styles.image} />
                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ParentChild')}>
                    <Text style={styles.buttonText}>Parent / Child</Text>
                </TouchableOpacity>
                <Image source={require('/Users/ntf-m4/Desktop/notification/src/Assets/2ndprent.png')} style={styles.image} />
                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Store')}>
                    <Text style={styles.buttonText}>View My Notifications</Text>
                </TouchableOpacity>
            </View>
            <View style={styles.bottom}>
                <View style={styles.box}>
                    <Text style={styles.boxText}>Last Paired :- {lastSignInTime ? lastSignInTime : '---'}</Text>
                    <Text style={styles.boxText}>Disconnected at: ---</Text>
                </View>
            </View>
        </ScrollView>
    );
};

const windowHeight = Dimensions.get('window').height;
const windowWidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        justifyContent: 'space-between',
        backgroundColor: '#fff',
        paddingHorizontal: 20,
        paddingVertical: windowHeight * 0.01,
    },
    top: {
        alignItems: 'center',
        marginTop: 20,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    middle: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        width: windowWidth * 0.41, // Adjust as needed
        height: windowWidth * 0.43, // Adjust as needed
        resizeMode: 'contain',
    },
    button: {
        backgroundColor: '#FF4155',
        paddingVertical: 9,
        borderRadius: 10,
        marginBottom: 40,
        width: windowWidth * 0.7, // Adjust as needed
    },
    buttonText: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 18,
    },
    viewLog: {
        color: '#FF4155',
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 18,
    },
    bottom: {
        alignItems: 'center',
    },
    boldText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: 'black',
    },
    logButton: {
        borderRadius: 10,
        marginBottom: 10,
    },
    notificationButton: {
        width: windowWidth * 0.6, // Adjust as needed
        marginBottom: 30,
    },
    box: {
        backgroundColor: '#F5F5F5',
        borderRadius: 10,
        padding: 15,
        marginBottom: 40,
        width: windowWidth * 0.8, // Adjust as needed
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5, // for Android
    },
    boxText: {
        fontSize: 14,
        marginBottom: 10,
        color: 'black'
    },
});

export default UseCases;
