import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import storage from '@react-native-firebase/storage';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ParentScreen = () => {
    const [uniqueID, setuniqueID] = useState('');
    const navigation = useNavigation();

    const getData = async () => {
        if (uniqueID === '') {
            Alert.alert('Enter Unique Key', "Please enter a unique key");
        } else {
            try {
                const filename = uniqueID;
                await AsyncStorage.setItem('Childs_ID', uniqueID)
                const reference = storage().ref(`uploads/notifications_${filename}.json`);
                const url = await reference.getDownloadURL();
                const response = await fetch(url);
                const data = await response.json();
                console.log('filename>>>', filename);
                navigation.navigate('ShowData', { filename });
            } catch (error) {
                if (error.code === 'storage/object-not-found') {
                    Alert.alert('No data found', 'Re-enter key');
                } else {
                    console.error('Error downloading data from Firebase Storage:', error);
                }
                setRefreshing(false);
            }
        }
    };
    return (
        <View style={styles.container}>
            <View style={styles.top}>
                <Text style={styles.topText}>Get Notifications Enter Key</Text>
            </View>
            <TextInput
                style={styles.input}
                value={uniqueID}
                onChangeText={setuniqueID}
                placeholder="Enter a unique key"
            />
            <TouchableOpacity style={styles.getDataButton} onPress={getData}>
                <Text style={styles.getDataButtonText}>Get Data</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        // flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 100
    },
    topText: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    input: {
        marginTop: 80,
        width: '80%',
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        marginBottom: 20,
        borderRadius: 5,
    },
    getDataButton: {
        backgroundColor: '#FF4155',
        paddingVertical: 10,
        paddingHorizontal: 30,
        borderRadius: 10,
    },
    getDataButtonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 18,
    },
});

export default ParentScreen;
