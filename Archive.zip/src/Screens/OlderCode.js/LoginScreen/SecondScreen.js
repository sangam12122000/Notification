import { useNavigation, useRoute } from '@react-navigation/native';
import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';

const SecondScreen = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const navigation = useNavigation();
    const route = useRoute(); // Use useRoute hook to access route parameters
    const totalPages = route.params?.totalPages ?? 1; // Access totalPages parameter from route params

    return (
        <View style={styles.container}>
            <View style={styles.content}>
                <View style={styles.top}>
                    <Text style={styles.text}>Choose apps of your child's device to monitor notifications</Text>
                </View>
                <View style={styles.middle}>
                    <Image source={require('/Users/ntf-m4/Desktop/notification/src/Assets/2ndprent.png')} style={styles.image} />
                    <Text style={styles.imageText}>You can monitor notification of all apps or few apps too.</Text>

                </View>
                <View style={styles.bottom}>
                    <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('GoogleLogin')}>
                        <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#FF4155' }}>Skip</Text>
                    </TouchableOpacity>
                    <Text style={styles.pageText}>{totalPages}/{totalPages}</Text>
                    <TouchableOpacity style={styles.nextButton} onPress={() => navigation.navigate('GoogleLogin')}>
                        <Text style={styles.nextButtonText}>{'>'}</Text>
                    </TouchableOpacity>
                </View>
            </View>
            <View style={styles.circleContainer}>
                <View style={styles.circle} />
            </View>
        </View>
    );
};

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    content: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 50,
        zIndex: 1, // Ensure content is above the circle
    },
    top: {
        alignItems: 'center',
    },
    imageText: {
        fontSize: 18,
        textAlign: 'center',
        color: '#827e7e',
        fontWeight: '500',
    },
    middle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    bottom: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    text: {
        fontSize: 18,
        textAlign: 'center',
        color: '#FF4155',
        fontWeight: '600',
    },
    button: {
        padding: 10,
        borderRadius: 5,
    },
    nextButton: {
        backgroundColor: '#FF4155',
        borderRadius: 25,
        width: 45,
        height: 45,
        alignItems: 'center',
    },
    nextButtonText: {
        color: 'white',
        fontSize: 30,
        fontWeight: '500'
    },
    image: {
        width: windowWidth * 0.6,
        height: windowWidth * 0.6,
        resizeMode: 'contain',
    },
    pageText: {
        fontSize: 17,
        fontWeight: 'bold',
        marginTop: 12,
    },
    circleContainer: {
        position: 'absolute',
        bottom: -windowHeight * 0.20, // Adjust to place the circle correctly
        left: 0,
        right: 0,
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 0, // Set a lower zIndex for the circle container
    },
    circle: {
        width: windowHeight * 0.65, // Adjust the size of the circle as needed
        height: windowHeight * 0.65,
        borderRadius: (windowHeight * 0.5) / 2,
        backgroundColor: 'rgba(255, 65, 85, 0.15)', // Lighter background color with transparency
    },
});

export default SecondScreen;
