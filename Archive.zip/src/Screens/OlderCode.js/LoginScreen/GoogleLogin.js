// Import necessary modules from React Native
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { GoogleSignin, GoogleSigninButton, statusCodes } from '@react-native-google-signin/google-signin';
import auth from '@react-native-firebase/auth';

const GoogleLogin = () => {
    const navigation = useNavigation();
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        GoogleSignin.configure({
            webClientId: '650419485217-5745u708upviq5576gbsle3okggufhd1.apps.googleusercontent.com'
        });
    }, []);


    const handleGoogleSignIn = async () => {
        try {
            await GoogleSignin.hasPlayServices();
            const userInfo = await GoogleSignin.signIn();
            const googleCredential = auth.GoogleAuthProvider.credential(userInfo.idToken);
            await auth().signInWithCredential(googleCredential);
            console.log('Successfully Google Login!');
            navigation.navigate('UseCases');
        } catch (error) {
            console.error('Google Sign-In error:', error);
        }
    };
    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.top}>
                <Text style={styles.title}>Same Notification</Text>
            </View>
            <View style={styles.middle}>
                <View style={styles.box}>
                    <Text style={styles.boxText}>Signup/Login</Text>
                    <View style={styles.bulletText}>
                        <Text style={styles.bullet}>{'\u2022'}</Text>
                        <Text style={styles.bulletColor}> Same Notification is designed, developed, and marketed for parents to monitor their children.</Text>
                    </View>
                    <View style={styles.bulletText}>
                        <Text style={styles.bullet}>{'\u2022'}</Text>
                        <Text style={styles.bulletColor}> This app should not be used to track anyone else (a spouse, for example) even with their knowledge and permission.</Text>
                    </View>
                    <View style={styles.bulletText}>
                        <Text style={styles.bullet}>{'\u2022'}</Text>
                        <Text style={styles.bulletColor}> Kindly do not use the application if an unknown person asks you to install this application. Pairing with an unknown person is not advised.</Text>
                    </View>
                    <View style={styles.bulletText}>
                        <Text style={styles.bullet}>{'\u2022'}</Text>
                        <Text style={styles.bulletColor}> Make sure to read our terms and conditions and privacy policy before using the app.</Text>
                    </View>
                    {/* <TouchableOpacity style={styles.button} onPress={signInWithGoogle}> */}
                    <GoogleSigninButton
                        style={{ width: 280, height: 52 }}
                        size={GoogleSigninButton.Size.Wide}
                        color={GoogleSigninButton.Color.Dark}
                        onPress={handleGoogleSignIn}
                    />

                    {/* </TouchableOpacity> */}

                    <View style={styles.termsAndPrivacyContainer}>
                        <Text>
                            By clicking Sign in with Google/OTP, you agree to our{' '}
                            <Text style={styles.termsAndPrivacyButton}>Terms and Conditions</Text>{' '}
                            and{' '}
                            <Text style={styles.termsAndPrivacyButton}>Privacy Statement</Text>
                        </Text>
                    </View>

                </View>
            </View>
        </ScrollView>
    );
};

const windowHeight = Dimensions.get('window').height;
const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: '#f2f0f0',
        paddingHorizontal: 20,
        paddingVertical: windowHeight * 0.15,
    },
    top: {
        marginBottom: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    middle: {
        justifyContent: 'center',
    },
    box: {
        backgroundColor: '#fff',
        borderRadius: 10,
        padding: 20,
        marginBottom: 20,
    },
    boxText: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    bulletText: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    bullet: {
        fontSize: 18,
        marginRight: 5,
    },
    bulletColor: {
        color: '#FF4155',
        fontSize: 15,
        fontWeight: '600'
    },
    button: {
        backgroundColor: '#FF4155',
        paddingVertical: 15,
        borderRadius: 10,
        marginVertical: 25,
        marginBottom: 10,
    },
    buttonText: {
        color: 'white',
        textAlign: 'center',
        fontSize: 18,
        fontWeight: 'bold',
    },
    termsAndPrivacyContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 10,
    },
    termsAndPrivacyButton: {
        color: '#FF4155',
        textDecorationLine: 'underline',
    },
});

export default GoogleLogin;
