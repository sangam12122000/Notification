import { useEffect } from 'react';
import { Platform, Text, View, PermissionsAndroid, Button } from 'react-native';
import RNAndroidNotificationListener from 'react-native-android-notification-listener';
import PushNotification, { Importance } from 'react-native-push-notification';
import Store from './src/Store';

const App = () => {

    useEffect(() => {
        requestNotificationPermission();
    }, []);

    const checkPermissionAndRegister = async () => {
        RNAndroidNotificationListener.requestPermission()

    }
    async function requestNotificationPermission() {
        if (Platform.OS === 'android') {
            try {
                const granted = await PermissionsAndroid.request(
                    PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS
                );
                if (granted === PermissionsAndroid.RESULTS.GRANTED) {
                    console.log('Notification permission granted');
                    const status = await RNAndroidNotificationListener.getPermissionStatus();
                    if (status === "denied" || status === "unknown") {
                        checkPermissionAndRegister()
                    }

                } else {
                    console.log('Notification permission denied');
                }
            } catch (err) {
                console.warn(err);
            }
        }
    }

    return (
        <View style={{ flex: 1 }}>
            <Store />
        </View>
    );
};

export default App;
