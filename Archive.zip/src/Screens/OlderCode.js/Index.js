import React, { useState, useEffect, useRef } from 'react';
import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import PushNotification, { Importance } from 'react-native-push-notification';
import { RNAndroidNotificationListenerHeadlessJsName } from 'react-native-android-notification-listener';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Main = () => {
    const [sendNotificationCalled, setSendNotificationCalled] = useState(false);
    useEffect(() => {
        PushNotification.createChannel(
            {
                channelId: "notification-channel-id",
                channelName: "My Notification Channel",
                channelDescription: "A channel to categorize your notifications.",
                soundName: "default",
                importance: Importance.HIGH,
                vibrate: true,
            },
            (created) => console.log(`Channel created: ${created}`)
        );
    }, []);

    const sendLocalNotification = (notification, run) => {
        console.log('RUN>>>>>>>1');
        if (run) {
            console.log('RUN>>>>>>>2');
            PushNotification.localNotification({
                channelId: "notification-channel-id",
                title: notification?.title,
                message: notification?.text,
                playSound: true,
                soundName: "default",
                vibrate: true,
                smallIcon: notification?.icon
            });
            setSendNotificationCalled(false);
        }
    };

    const handleBackgroundNotification = async ({ notification }) => {
        try {
            const notificationData = JSON.parse(notification);
            console.log("Data1", notificationData);
            console.log("Data2", notification);
            if (notificationData && !sendNotificationCalled &&
                (notificationData.app.includes('com.android.vending')
                    || notificationData.app.includes('com.xiaomi.mipicks')
                    || notificationData.text.includes('Messages is doing work in the background')
                    || notificationData.app.includes('com.mayur89821')
                    || notificationData.title.includes('Charging this device via USB')
                )) {
                console.log("ENTEREDDDDD1");
                setSendNotificationCalled(false);
            } else if (!sendNotificationCalled) {
                console.log("ENTEREDDDDD2", notificationData);
                //STORAGEE
                if (notificationData.text !== ''
                    && !notificationData.title.includes('Charging this device via USB')
                    && !notificationData.title.includes('USB debugging connected')) {
                    sendLocalNotification(notificationData, run = true);
                    setSendNotificationCalled(true);
                    let existingNotifications = await AsyncStorage.getItem('notifications');
                    existingNotifications = existingNotifications ? JSON.parse(existingNotifications) : [];
                    existingNotifications.push(notificationData);
                    await AsyncStorage.setItem('notifications', JSON.stringify(existingNotifications));
                }
            } else {
                console.log("ENTEREDDDDD3");
                setSendNotificationCalled(false);
            }
        } catch (error) {
            console.error("error:", error);
        }
    };
    AppRegistry.registerHeadlessTask(RNAndroidNotificationListenerHeadlessJsName, () => handleBackgroundNotification);

    return <App />;
};

AppRegistry.registerComponent(appName, () => Main);
