import React, { useState } from 'react';
import { Text, View, ScrollView, Image, TouchableOpacity, Platform, UIManager, LayoutAnimation } from 'react-native';
import styles from './Style';
import Clipboard from '@react-native-clipboard/clipboard';

const NotificationItem = ({ notification }) => {
    const [showFullText, setShowFullText] = useState(false);
    const [showGroupedMessages, setShowGroupedMessages] = useState(false);
    const [expanded, setExpanded] = useState(false);

    Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental && UIManager.setLayoutAnimationEnabledExperimental(true);

    let appName = notification.app.split('.').pop();
    if (notification.app.toLowerCase().includes('messaging')) {
        appName = 'Message';
    } else if (notification.app.toLowerCase().includes('notification')) {
        appName = 'App Notification';
    } else if (notification.app.toLowerCase() === 'com.google.android.youtube') {
        appName = 'Youtube';
    } else if (notification.app.toLowerCase().includes('android')) {
        appName = 'Android';
    } else if (notification.app.toLowerCase().startsWith('com.')) {
        appName = appName.charAt(0).toUpperCase() + appName.slice(1);
    }

    const toggleFullText = () => {
        setShowFullText(!showFullText);
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setExpanded(!expanded);
    };

    const toggleGroupedMessages = () => {
        setShowGroupedMessages(!showGroupedMessages);
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
        setExpanded(!expanded);
    };

    const options = { hour: 'numeric', minute: 'numeric' };
    const formatDate = (date) => {
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear().toString().slice(-2);
        return `${day}/${month}/${year}`;
    };

    return (
        <TouchableOpacity style={styles.notificationWrapper} disabled={true}>
            <View style={styles.notificationContainer}>
                <View style={styles.iconContainer}>
                    {notification.icon ? (
                        <Image
                            style={styles.icon}
                            source={{ uri: notification.icon }}
                        />
                    ) : (
                        notification.app.toLowerCase().includes('whatsapp') ? (
                            <Image
                                style={styles.Emptyicon}
                                source={require('/Users/ntf-m4/Desktop/notification/src/Assets/whatsapp.png')}
                            />
                        ) : (
                            notification.app.toLowerCase().includes('telegram') ? (
                                <Image
                                    style={styles.Emptyicon}
                                    source={require('/Users/ntf-m4/Desktop/notification/src/Assets/telegram.png')}
                                />
                            ) : (
                                notification.app.toLowerCase().includes('messaging') ? (
                                    <Image
                                        style={styles.Emptyicon}
                                        source={require('/Users/ntf-m4/Desktop/notification/src/Assets/chat.png')}
                                    />
                                ) : (
                                    notification.app.toLowerCase() === 'com.google.android.youtube' ? (
                                        <Image
                                            style={styles.Emptyicon}
                                            source={require('/Users/ntf-m4/Desktop/notification/src/Assets/youtube.png')}
                                        />
                                    ) : (
                                        notification.app.toLowerCase().includes('slack') ? (
                                            <Image
                                                style={styles.Emptyicon}
                                                source={require('/Users/ntf-m4/Desktop/notification/src/Assets/slack.png')}
                                            />
                                        ) : (
                                            <Image
                                                style={styles.Emptyicon}
                                                source={require('/Users/ntf-m4/Desktop/notification/src/Assets/download.png')}
                                            />
                                        )
                                    )
                                )
                            )
                        )
                    )}
                </View>

                <View style={styles.notificationContent}>
                    {/* Display App Name  */}
                    <Text style={styles.appName}>{appName}</Text>
                    {/* Display Title  */}
                    <TouchableOpacity onPress={toggleFullText}>
                        <Text style={styles.sender}>
                            {showFullText ? notification.title : notification.title.length > 24 ? notification.title.slice(0, 24) : notification.title}
                            {!showFullText && notification.title.length > 24 && <Text style={styles.ellipsis}>...</Text>}
                        </Text>
                        {/* Display text  */}
                        {/* {console.log('GROUP MESSAGE>>', notification.groupedMessages)} */}
                        <Text style={styles.message}>
                            {showGroupedMessages && notification.groupedMessages && notification.groupedMessages.length > 0 ?
                                notification.groupedMessages.map((msg, index) => (
                                    <Text key={index}>{msg.text}{'\n\n'}</Text> // Add spaces or newline here
                                )) :
                                (showFullText ? notification.text : notification.text.length > 24 ? notification.text.slice(0, 24) : notification.text)
                            }
                            {!showFullText && notification.text.length > 24 && <Text style={styles.ellipsis}>...</Text>}
                        </Text>

                    </TouchableOpacity>
                </View>
                <View style={styles.timeAndDateContainer}>
                    <View style={styles.timeContainer}>
                        <Text style={styles.time}>
                            {new Date(parseInt(notification.time)).toLocaleTimeString([], options)}
                        </Text>
                    </View>
                    <View style={styles.dateContainer}>
                        <Text style={styles.date}>
                            {formatDate(new Date(parseInt(notification.time)))}
                        </Text>
                    </View>

                    {notification.groupedMessages && notification.groupedMessages.length > 0 &&
                        <TouchableOpacity onPress={toggleGroupedMessages}>
                            <Text style={{ fontSize: 12, marginTop: 25, color: '#0390fc' }}>{showGroupedMessages ? 'Hide' : 'See more'}</Text>
                        </TouchableOpacity>
                    }
                </View>
            </View>
        </TouchableOpacity>
    );
};
const NotificationList = ({ notifications }) => {
    return (
        <View style={styles.scroll}>
            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {notifications.slice().reverse().map((notification, index) => (
                    <NotificationItem key={index} notification={notification} />
                ))}
            </ScrollView>
        </View>
    );
};

export default NotificationList;
