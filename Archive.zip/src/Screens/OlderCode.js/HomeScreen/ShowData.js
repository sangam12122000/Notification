import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, Image } from 'react-native';
import storage from '@react-native-firebase/storage';
import { useRoute } from '@react-navigation/native';
import NotificationList from './NotificationList';
import { useNavigation } from '@react-navigation/native';

const ShowData = () => {
    const [notifications, setNotifications] = useState([]);
    const [refreshing, setRefreshing] = useState(false);
    const route = useRoute();
    const navigation = useNavigation();
    const { filename } = route.params;

    useEffect(() => {
        console.log("Fetching Data In Firebase...");
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const { filename } = route.params;
            const reference = storage().ref(`uploads/notifications_${filename}.json`);
            const url = await reference.getDownloadURL();
            const response = await fetch(url);
            const data = await response.json();
            setNotifications(data);
            setRefreshing(false);
        } catch (error) {
            if (error.code === 'storage/object-not-found') {
                alert('No data found');
            } else {
                console.error('Error downloading data from Firebase Storage:', error);
            }
            setRefreshing(false);
        }
    };

    const handleRefresh = () => {
        console.log("Fetching Data In Firebase...");
        setRefreshing(true);
        fetchData();
    };

    const handleNavigate = () => {
        navigation.navigate('ParentScreen', { keyID: false });
    };

    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.delBtn} onPress={handleNavigate}>
                <Text style={{ color: 'white', fontWeight: 'bold' }}>Re-enter key</Text>
            </TouchableOpacity>
            <ScrollView
                style={styles.scrollView}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={handleRefresh}
                    />
                }
            >
                {notifications.length === 0 ? (
                    <Text style={styles.noRecent}>No Recent Notifications</Text>
                ) : (
                    <NotificationList notifications={notifications} />
                )}
            </ScrollView>
        </View>
    );

};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
    },
    scrollView: {
        flex: 1,
    },
    delBtn: {
        position: 'absolute',
        bottom: 30,
        left: 20,
        alignItems: 'center',
        backgroundColor: 'rgba(255, 65, 85, 0.8)',
        color: 'white',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 10,
        zIndex: 1,
    },
    noRecent: {
        fontSize: 25,
        marginHorizontal: 25
    }
});




export default ShowData;
