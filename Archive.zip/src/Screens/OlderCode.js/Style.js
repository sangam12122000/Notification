import { Dimensions, StyleSheet } from 'react-native';

const { width } = Dimensions.get('screen');

export default styles = {
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: 20,
        marginTop: 20,
    },
    button: {
        backgroundColor: '#55a1f2',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 5,
        marginHorizontal: 5, // Adjust horizontal margin as needed
    },
    delBtn: {
        backgroundColor: '#eb4f44',
        paddingVertical: 10,
        paddingHorizontal: 12,
        borderRadius: 5,
        marginHorizontal: 2,
    },
    noRecent: {
        fontSize: 25,
        marginHorizontal: 25
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        textAlign: 'center',
        width: 200
    },
    scroll: {
        flex: 1,
        backgroundColor: '#fff',
    },
    scrollContent: {
        flexGrow: 1,
        paddingBottom: 20,
    },
    notificationWrapper: {
        backgroundColor: '#fff',
        borderRadius: 10,
        marginHorizontal: 20,
        marginVertical: 5,
        padding: 15,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },
    notificationContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    iconContainer: {
        width: 50, // Adjust width as needed
        height: 50, // Adjust height as needed
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 10, // Adjust margin as needed
    },
    icon: {
        width: '100%',
        height: '100%',
        resizeMode: 'contain', // Adjust resizeMode as needed
    },
    refresh: {
        height: 20,
        width: 20,
        resizeMode: 'contain'
    },
    Emptyicon: {
        width: '80%',
        height: '80%',
        resizeMode: 'contain',
    },
    notificationContent: {
        flex: 1,
    },
    appName: {
        fontSize: 13,
        fontWeight: 'bold',
        marginBottom: 5,
        color: '#333',
    },
    sender: {
        fontWeight: '500',
        marginBottom: 2,
        color: '#555',
    },
    message: {
        marginBottom: 2,
        color: '#777',
    },
    timeAndDateContainer: {
        // marginTop: 10, // Adjust this value as needed
    },
    timeContainer: {

    },
    dateContainer: {
    },
    time: {
        fontSize: 10,
        color: '#999',
    },
    date: {
        fontSize: 10,
        color: '#888',
    },
    ellipsis: {
        color: 'gray',
        fontSize: 15,
        fontWeight: 'bold'
    }, notificationListContainer: {
        flex: 1,
        marginTop: 10,
    },
    copyButton: {
        height: 20,
        width: 20,
        marginLeft: 22,
        // marginTop: 40,
        resizeMode: 'contain', // Adjust resizeMode as needed

    },
};
