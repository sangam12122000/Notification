import React, { useState, useEffect, useCallback } from 'react';
import {
    SafeAreaView,
    ScrollView,
    Text,
    View,
    Image,
    TouchableOpacity,
    ActivityIndicator,
    RefreshControl
} from 'react-native';
import RNAndroidNotificationListener from 'react-native-android-notification-listener';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './Style';
import NotificationList from './NotificationList';

function Store() {
    const [hasPermission, setHasPermission] = useState(false);
    const [lastNotifications, setLastNotifications] = useState([]);
    const [delLoading, setDelLoading] = useState(false);
    const [refreshing, setRefreshing] = useState(false);

    const handleOnPressPermissionButton = async () => {
        RNAndroidNotificationListener.requestPermission();
    };

    const handleAppStateChange = async (nextAppState, force = false) => {
        if (nextAppState === 'active' || force) {
            const status = await RNAndroidNotificationListener.getPermissionStatus();
            setHasPermission(status !== 'denied');
        }
    };
    useEffect(() => {
        let interval = null;
        clearInterval(interval);
        interval = setInterval(handleNotificationShow, 2000);
        handleAppStateChange('', true);
    }, []);

    const handleNotificationShow = useCallback(async () => {
        try {
            const allNotifications = await AsyncStorage.getItem('notifications');
            if (allNotifications) {
                const notifications = JSON.parse(allNotifications);
                setLastNotifications(notifications);
            } else {
                console.log('No notifications found.');
            }
        } catch (error) {
            console.error('Error retrieving notifications:', error);
        }
    }, []);
    const handleRefresh = useCallback(() => {
        setRefreshing(true);
        handleNotificationShow();
        setTimeout(() => {
            setRefreshing(false);
        }, 2000);
    }, [handleNotificationShow]);

    const handleDelete = async () => {
        setDelLoading(true);
        setTimeout(async () => {
            setDelLoading(false);
            if (lastNotifications.length > 0) {
                await AsyncStorage.removeItem('notifications');
                setLastNotifications([]);
            }
        }, 2000);
    };
    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.buttonContainer}>
                <TouchableOpacity
                    disabled={hasPermission}
                    style={[styles.button, { backgroundColor: hasPermission ? '#b8c3cf' : '#007bff' }]}
                    onPress={handleOnPressPermissionButton}>
                    <Text style={styles.buttonText}>Permission for Android</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.delBtn} onPress={handleDelete} disabled={delLoading}>
                    {delLoading ? (
                        <ActivityIndicator size="small" color="#ffffff" />
                    ) : (
                        <Image
                            source={require('/Users/ntf-m4/Desktop/notification/src/Assets/delete.png')}
                            style={{
                                height: 20,
                                width: 20,
                                resizeMode: 'contain',
                            }}
                        />
                    )}
                </TouchableOpacity>
            </View>
            <ScrollView
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={handleRefresh}
                        colors={['#55a1f2']}
                    />
                }>
                {lastNotifications.length === 0 ? (
                    <Text style={styles.noRecent}>No Recent Notifications</Text>
                ) : (
                    <NotificationList notifications={lastNotifications} />
                )}
            </ScrollView>
        </SafeAreaView>
    );
}
export default Store;
