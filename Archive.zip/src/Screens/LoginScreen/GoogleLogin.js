import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    Dimensions,
    TextInput,
    TouchableOpacity,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { useNavigation, useRoute, useIsFocused } from '@react-navigation/native';
import { GoogleSignin, GoogleSigninButton, statusCodes } from '@react-native-google-signin/google-signin';
import auth from '@react-native-firebase/auth';

const GoogleLogin = () => {
    const navigation = useNavigation();
    const route = useRoute();
    const isFocused = useIsFocused();
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    useEffect(() => {
        GoogleSignin.configure({
            webClientId: '650419485217-5745u708upviq5576gbsle3okggufhd1.apps.googleusercontent.com',
        });

        const checkUserLogin = async () => {
            const currentUser = auth().currentUser;
            console.log('currentUser>>>', currentUser);
            if (currentUser && isFocused) {
                navigation.navigate('UseCases');
            }
        };

        checkUserLogin();
        const emailFromParams = route?.params?.email;
        if (emailFromParams) {
            setEmail(emailFromParams);
        }
    }, [route.params, isFocused]);

    const handleEmailLogin = async () => {
        try {
            if (!email || !password) {
                Alert.alert('Validation Error', 'Email and password are required.');
                setLoading(false);
                return;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                Alert.alert('Validation Error', 'Please enter a valid email address.');
                setLoading(false);
                return;
            }

            const passwordRegex = /^(?=.*[A-Z])[A-Za-z\d@$!%*?&]{6,}$/;
            if (!passwordRegex.test(password)) {
                Alert.alert(
                    'Validation Error',
                    'Password must be at least 6 characters long and contain at least one uppercase letter.'
                );
                setLoading(false);
                return;
            }
            setLoading(true);
            const response = await auth().signInWithEmailAndPassword(email, password);
            console.log('Successfully logged in:', response.user.email);
            setEmail('');
            setPassword('');
            navigation.navigate('UseCases');
        } catch (error) {
            if (error.code === 'auth/invalid-credential') {
                Alert.alert('Email or Password Incorrect', 'Please check your email and password.');
            } else {
                Alert.alert('Email Login Error', error.message);
            }
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleSignIn = async () => {
        try {
            await GoogleSignin.hasPlayServices();
            const userInfo = await GoogleSignin.signIn();
            const googleCredential = auth.GoogleAuthProvider.credential(userInfo.idToken);
            await auth().signInWithCredential(googleCredential);
            console.log('Successfully Google Login!');
            navigation.navigate('UseCases');
        } catch (error) {
            if (error.code === statusCodes.SIGN_IN_CANCELLED) {
                console.log('Google Sign-In cancelled');
                Alert.alert('Please select a google account', 'For google login');
            } else {
                Alert.alert('Google Sign-In error:', error);
            }
        }
    };

    const handleDelayedLogin = () => {
        setLoading(true);
        setTimeout(() => {
            handleEmailLogin();
        }, 1000);
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.middle}>
                <View style={styles.box}>
                    <View style={styles.top}>
                        <Text style={styles.title}>Login</Text>
                    </View>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter Your Email"
                        onChangeText={setEmail}
                        value={email}
                        keyboardType="email-address"
                        autoCapitalize="none"
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Password"
                        onChangeText={setPassword}
                        value={password}
                        secureTextEntry
                    />
                    <TouchableOpacity style={styles.button} onPress={handleDelayedLogin} disabled={loading}>
                        {loading ? (
                            <ActivityIndicator color="white" size={24} />
                        ) : (
                            <Text style={styles.buttonText}>Login</Text>
                        )}
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.createAccountButton}
                        disabled={loading}
                        onPress={() => navigation.navigate('CreateAccount')}>
                        <Text style={styles.createAccountText}>Create Account?</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.googleButtonContainer}>
                    <GoogleSigninButton
                        style={styles.googleButton}
                        size={GoogleSigninButton.Size.Wide}
                        color={GoogleSigninButton.Color.Dark}
                        onPress={handleGoogleSignIn}
                    />
                </View>
                <View style={styles.termsAndPrivacyContainer}>
                    <Text>
                        By clicking Sign in with Google/OTP, you agree to our{' '}
                        <Text style={styles.termsAndPrivacyButton}>Terms and Conditions</Text> and{' '}
                        <Text style={styles.termsAndPrivacyButton}>Privacy Statement</Text>
                    </Text>
                </View>
            </View>
        </ScrollView>
    );
};

const windowHeight = Dimensions.get('window').height;
const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: '#fff',
        paddingHorizontal: 20,
        paddingVertical: windowHeight * 0.15,
    },
    top: {
        marginBottom: 20,
    },
    title: {
        fontSize: 30,
        fontWeight: '600',
        textAlign: 'center',
        color: '#508ccc',
    },
    createAccountText: {
        fontSize: 14,
        fontWeight: 'bold',
        textAlign: 'right',
        color: '#508ccc',
        marginTop: 10
    },
    middle: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#f9f9f9',
        borderRadius: 10,
        padding: 20,
        marginBottom: 20,
        width: '100%',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
    },

    input: {
        backgroundColor: '#fff',
        borderRadius: 8,
        padding: 12,
        marginBottom: 15,
        width: '100%',
        borderColor: '#ccc',
        borderWidth: 1,
    },
    button: {
        backgroundColor: '#f04d5b',
        paddingVertical: 15,
        borderRadius: 10,
        marginBottom: 10,
        width: '100%',
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        textAlign: 'center',
        fontSize: 18,
        fontWeight: 'bold',
    },
    createAccountButton: {
        marginBottom: 10,
    },
    googleButtonContainer: {
        marginTop: 20,
        width: '100%',
        alignItems: 'center',
    },
    googleButton: {
        width: 280,
        height: 50,
    },
    termsAndPrivacyContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 10,
    },
    termsAndPrivacyButton: {
        color: '#f04d5b',
        textDecorationLine: 'underline',
    },
});

export default GoogleLogin;
