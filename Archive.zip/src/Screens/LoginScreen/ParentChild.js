import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ParentChild = () => {
    const navigation = useNavigation();
    const isFocused = useIsFocused();
    const [child_id, setChild_id] = useState('');

    useEffect(() => {
        if (isFocused) {
            hanldeCheckChild_id();
        }
    }, [isFocused]);

    const hanldeCheckChild_id = async () => {
        const Childs_ID = await AsyncStorage.getItem('Childs_ID');
        if (child_id) {
            await AsyncStorage.setItem('Childs_ID', '');
        }
        console.log('Childs_ID>>>>', Childs_ID);
        setChild_id(Childs_ID);
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.top}>
                <Text style={styles.title}>What's Your Use case?</Text>
            </View>
            <View style={styles.middle}>
                <Image source={require('/Users/ntf-m4/Desktop/notification/src/Assets/couple.png')} style={styles.image} />
                <View style={styles.circleContainer}>
                    <View style={styles.circle} />
                </View>
                <TouchableOpacity
                    style={styles.button}
                    onPress={() => navigation.navigate('ParentScreen')}
                >
                    <Text style={styles.buttonText}>Parent</Text>
                </TouchableOpacity>
                <Image source={require('/Users/ntf-m4/Desktop/notification/src/Assets/boy1.png')} style={styles.image} />
                <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ChildScreen')}>
                    <Text style={styles.buttonText}>Child</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingHorizontal: 20,
        // paddingVertical: windowHeight * 0.09,
    },

    title: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 30,
    },
    middle: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        width: windowWidth * 0.4,
        height: windowWidth * 0.4,
        resizeMode: 'contain',
    },
    button: {
        backgroundColor: '#FF4155',
        paddingVertical: 9,
        borderRadius: 10,
        marginBottom: 30,
        width: windowWidth * 0.7,
    },
    buttonText: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 18,
    },
    circleContainer: {
        position: 'absolute',
        bottom: -windowHeight * 0.3,
        left: 0,
        right: 0,
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 0,
    },
    circle: {
        width: windowHeight * 0.62,
        height: windowHeight * 0.66,
        borderRadius: windowHeight * 0.55 / 2,
        backgroundColor: 'rgba(255, 65, 85, 0.15)',
    },
});

export default ParentChild;
