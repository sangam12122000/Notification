import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import auth from '@react-native-firebase/auth'; // Import Firebase auth module

const CreateAccount = () => {
    const navigation = useNavigation();
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleRegister = async () => {
        try {
            setLoading(true);
            if (!email || !password) {
                Alert.alert('Validation Error', 'Email and password are required.');
                setLoading(false);
                return;
            }
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                Alert.alert('Validation Error', 'Please enter a valid email address.');
                setLoading(false);
                return;
            }

            const passwordRegex = /^(?=.*[A-Z])[A-Za-z\d@$!%*?&]{6,}$/;
            if (!passwordRegex.test(password)) {
                Alert.alert(
                    'Validation Error',
                    'Password must be at least 6 characters long and contain at least one uppercase letter.'
                );
                setLoading(false);
                return;
            }

            setTimeout(async () => {
                await auth().createUserWithEmailAndPassword(email, password);
                Alert.alert('Success', 'Account created successfully');
                setLoading(false);
                navigation.navigate('GoogleLogin', { email });
            }, 2000);
        } catch (error) {
            setLoading(false);
            Alert.alert('Error', error.message);
        }
    };


    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.middle}>
                <View style={styles.box}>
                    <TextInput
                        style={styles.input}
                        placeholder="Enter Your Email"
                        onChangeText={setEmail}
                        value={email}
                        keyboardType="email-address"
                        autoCapitalize="none"
                    />
                    <TextInput
                        style={styles.input}
                        placeholder="Password"
                        onChangeText={setPassword}
                        value={password}
                        secureTextEntry
                    />
                    <TouchableOpacity
                        style={styles.button}
                        onPress={handleRegister} // Attach handleRegister function to onPress event
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator color="white" size={24} />
                        ) : (
                            <Text style={styles.buttonText}>Register</Text>
                        )}
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
};

const windowHeight = Dimensions.get('window').height;
const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: '#f2f0f0',
        paddingHorizontal: 20,
        paddingVertical: windowHeight * 0.15,
    },
    middle: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    box: {
        backgroundColor: '#fff',
        borderRadius: 10,
        padding: 20,
        marginBottom: 20,
        width: '100%',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5, // for Android
    },
    input: {
        backgroundColor: '#f9f9f9',
        borderRadius: 8,
        padding: 12,
        marginBottom: 15,
        width: '100%',
    },
    button: {
        backgroundColor: '#f04d5b',
        paddingVertical: 15,
        borderRadius: 10,
        marginBottom: 10,
        width: '100%',
        alignItems: 'center',
    },
    buttonText: {
        color: 'white',
        textAlign: 'center',
        fontSize: 18,
        fontWeight: 'bold',
    },
});


export default CreateAccount;
