import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Alert, ActivityIndicator, Dimensions, Keyboard } from 'react-native';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ParentScreen = () => {
    const [uniqueID, setUniqueID] = useState('');
    const [loading, setLoading] = useState(false);
    const navigation = useNavigation();
    const isFocused = useIsFocused();
    const inputRef = useRef(null);

    useEffect(() => {
        if (isFocused) {
            handleCheckChild_id();
            Keyboard.dismiss();
            if (inputRef.current) {
                inputRef.current.focus();
            }
        }
    }, [isFocused]);

    const handleCheckChild_id = async () => {
        const child_id = await AsyncStorage.getItem('Childs_ID');
        if (child_id) {
            navigation.navigate('ShowData', { filename: child_id });
        }
    }

    const getData = async () => {
        if (uniqueID === '') {
            Alert.alert('Enter Unique Key', "Please enter a unique key");
        } else {
            try {
                setLoading(true);
                const filename = uniqueID;
                setTimeout(() => {
                    setLoading(false);
                    navigation.navigate('ShowData', { filename, uniqueID });
                }, 2000);
            } catch (error) {
                if (error.code === 'storage/object-not-found') {
                    Alert.alert('No data found', 'Re-enter key');
                } else {
                    console.error('Error downloading data from Firebase Storage:', error);
                }
                setLoading(false);
            }
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.topText}>Get Notifications Enter Key</Text>
            <View style={styles.inputContainer}>
                <TextInput
                    ref={inputRef}
                    style={styles.input}
                    value={uniqueID}
                    onChangeText={setUniqueID}
                    placeholder="Enter child's key"
                    autoCapitalize='none'
                />
            </View>
            <TouchableOpacity style={styles.getDataButton} onPress={getData}>
                <Text style={styles.getDataButtonText}>Get Data</Text>
            </TouchableOpacity>
            {loading && (
                <View style={styles.activityIndicatorContainer}>
                    <ActivityIndicator size="large" color="#FF4155" />
                </View>
            )}
        </View>
    );
};

const { width, height } = Dimensions.get('window');
const windowHeight = Dimensions.get('window').height;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingVertical: windowHeight * 0.2,
    },
    topText: {
        fontSize: width * 0.05,
        fontWeight: 'bold',
    },
    inputContainer: {
        width: width * 0.75,
        borderRadius: width * 0.02,
        backgroundColor: '#fff',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.6,
        shadowRadius: 4,
        elevation: 4,
        marginBottom: height * 0.03,
        marginTop: height * 0.03,
    },
    input: {
        textAlign: 'center',
        fontSize: width * 0.04,
        padding: width * 0.03,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: width * 0.02,
    },
    getDataButton: {
        backgroundColor: '#FF4155',
        paddingVertical: height * 0.02,
        paddingHorizontal: width * 0.1,
        borderRadius: width * 0.05,
    },
    getDataButtonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: width * 0.04,
    },
    activityIndicatorContainer: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
});

export default ParentScreen;
