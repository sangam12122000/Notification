import Clipboard from '@react-native-clipboard/clipboard';
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
const ChildScreen = () => {
    const [generatedNumber, setGeneratedNumber] = useState('');

    useEffect(() => {
        generateUniqueId();
    }, []);

    const generateUniqueId = async () => {
        const id = await AsyncStorage.getItem('ID')
        setGeneratedNumber(id)
    };

    const copyToClipboard = () => {
        Clipboard.setString(generatedNumber);
    };
    return (
        <View style={styles.container}>
            <View style={styles.top}>
                <Text style={styles.topText}>Share Notification</Text>
            </View>
            <View style={styles.middle}>
                <Text style={styles.middleText}>Enter code on Parent's Device:</Text>
                <View style={styles.codeContainer}>
                    <Text style={styles.generatedCode}>{generatedNumber}</Text>
                </View>
                <View style={styles.buttonsContainer}>
                    <TouchableOpacity style={styles.copyButton} onPress={copyToClipboard}>
                        <Text style={styles.copyButtonText}>Copy</Text>
                    </TouchableOpacity>

                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 20,
    },
    top: {
        alignItems: 'center',
        marginBottom: 20,
        marginVertical: 80
    },
    topText: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    middle: {
        alignItems: 'center',
        marginBottom: 20,
        marginVertical: 70
    },
    middleText: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    codeContainer: {
        marginBottom: 20,
    },
    generatedCode: {
        fontSize: 24,
        fontWeight: 'bold',
    },
    buttonsContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
    },
    copyButton: {
        backgroundColor: '#FF4155',
        paddingVertical: 10,
        paddingHorizontal: 30,
        borderRadius: 10,
        marginBottom: 10,
        marginRight: 5,
    },
    copyButtonText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 18,
    },
    refreshButton: {
        borderRadius: 10,
    },
    refreshIcon: {
        width: 25,
        height: 25,
        resizeMode: 'contain',
        marginBottom: 12,
        tintColor: 'green'
    },
});

export default ChildScreen;
