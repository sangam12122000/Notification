import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const FirstScreen = () => {
    const navigation = useNavigation();
    const [firstTimeUser, setFirstTimeUser] = useState(true);

    useEffect(() => {
        AsyncStorage.getItem('visitedFirstScreen').then(value => {
            if (value) {
                setFirstTimeUser(false);
                navigation.navigate('SecondScreen');
            }
        });
    }, []);

    const goToSecondScreen = () => {
        AsyncStorage.setItem('visitedFirstScreen', 'true');
        navigation.navigate('SecondScreen');
    };

    if (!firstTimeUser) {
        return null;
    }

    return (
        <View style={styles.container}>
            <View style={styles.content}>
                <View style={styles.top}>
                    <Text style={styles.text}>Do you need to monitor your child's device?</Text>
                </View>
                <View style={styles.middle}>
                    <Image source={require('/Users/ntf-m4/Desktop/notification/src/Assets/family.png')} style={styles.image} />
                    <Text style={styles.imageText}>Track and secure your child from harmful activity by monitoring your child's device's notification in your device</Text>

                </View>
                <View style={styles.bottom}>
                    <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('UseCases')}>
                        <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#FF4155' }}>Skip</Text>
                    </TouchableOpacity>
                    <Text style={styles.pageText}>1/2</Text>
                    <TouchableOpacity style={styles.nextButton} onPress={goToSecondScreen}>
                        <Text style={styles.nextButtonText}>{'>'}</Text>
                    </TouchableOpacity>
                </View>
            </View>
            <View style={styles.circleContainer}>
                <View style={styles.circle} />
            </View>
        </View>
    );
};

const windowHeight = Dimensions.get('window').height;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    content: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 50,
        zIndex: 1,
    },
    top: {
        alignItems: 'center',
        marginTop: 20
    },
    middle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    bottom: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    text: {
        fontSize: 20,
        textAlign: 'center',
        color: '#FF4155',
        fontWeight: '600',
    },
    imageText: {
        fontSize: 18,
        textAlign: 'center',
        color: '#827e7e',
        fontWeight: '500',
    },
    button: {
        padding: 10,
        borderRadius: 5,
    },
    nextButton: {
        backgroundColor: '#FF4155',
        borderRadius: 25,
        width: 45,
        height: 45,
        alignItems: 'center',
    },
    nextButtonText: {
        color: 'white',
        fontSize: 30,
        fontWeight: '500'
    },
    image: {
        width: 220,
        height: 220,
        resizeMode: 'contain',
    },
    pageText: {
        fontSize: 17,
        fontWeight: 'bold',
        marginTop: 12,
    },
    circleContainer: {
        position: 'absolute',
        bottom: -windowHeight * 0.20,
        left: 0,
        right: 0,
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 0,
    },
    circle: {
        width: windowHeight * 0.65,
        height: windowHeight * 0.65,
        borderRadius: (windowHeight * 0.5) / 2,
        backgroundColor: 'rgba(255, 65, 85, 0.15)',
    },
});

export default FirstScreen;
