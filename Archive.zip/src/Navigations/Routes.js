import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Store from '../Screens/HomeScreen/Store';
import FirstScreen from '../Screens/LoginScreen/FirstScreen';
import SecondScreen from '../Screens/LoginScreen/SecondScreen';
import GoogleLogin from '../Screens/LoginScreen/GoogleLogin';
import UseCases from '../Screens/LoginScreen/UseCases';
import ParentChild from '../Screens/LoginScreen/ParentChild';
import ChildScreen from '../Screens/LoginScreen/ChildScreen';
import ParentScreen from '../Screens/LoginScreen/ParentScreen';
import ShowData from '../Screens/HomeScreen/ShowData';
import CreateAccount from '../Screens/LoginScreen/CreateAccount';
const Stack = createNativeStackNavigator();
function Routes() {
    return (
        <NavigationContainer>
            <Stack.Navigator>
                <Stack.Screen
                    name="FirstScreen"
                    component={FirstScreen}
                    options={{ headerShown: false }}
                />
                <Stack.Screen
                    name="SecondScreen"
                    component={SecondScreen}
                    options={{ headerShown: false }}
                />
                <Stack.Screen
                    name="GoogleLogin"
                    component={GoogleLogin}
                    options={{ headerShown: false }}
                />
                <Stack.Screen
                    name="UseCases"
                    component={UseCases}
                    options={{ headerShown: false }}
                />
                <Stack.Screen
                    name="ParentChild"
                    component={ParentChild}
                    options={{
                        headerShown: false,
                        headerTitle: "Select your case"
                    }} />
                <Stack.Screen
                    name="ChildScreen"
                    component={ChildScreen}
                    options={{
                        headerShown: true,
                        headerTitle: "Child's Key"
                    }} />
                <Stack.Screen
                    name="ParentScreen"
                    component={ParentScreen}
                    options={{
                        headerShown: true,
                        headerTitle: "Enter key",
                    }} />
                <Stack.Screen
                    name="ShowData"
                    component={ShowData}
                    options={{
                        headerShown: true,
                        headerTitle: "Child's Notifications",
                    }}
                />

                <Stack.Screen
                    name="Store"
                    component={Store}
                    options={{
                        headerShown: true,
                        headerTitle: "My Notifications"
                    }}
                />
                <Stack.Screen
                    name="CreateAccount"
                    component={CreateAccount}
                    options={{
                        headerShown: true,
                        headerTitle: "Register here"
                    }}
                />
            </Stack.Navigator>
        </NavigationContainer>
    )
}
export default Routes